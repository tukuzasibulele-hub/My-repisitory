package csc2b.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MusicClientPane extends GridPane //You may change the JavaFX pane layout
{
	private Button connect;
	private TextField Connection;
	private Socket client;
	private PrintWriter write;
	private BufferedReader read;
	private PasswordField username;
	private PasswordField password;
	private Button Login;
	private Text loginStatus;
	private Text text;
	private TextArea responses;
	private TextField ResultofLogin;
	private Button getList;
	private TextArea list;
	private TextField field;
	private Button download;
	private TextField result;
	private Button logout;
	
	
	
	
	
    public MusicClientPane(Stage stage) {
    	
    	
    	SetUP();
    	
    	connect.setOnAction(e->{
    		connection();
    		
    	});
    	Login.setOnAction(e->{
    		String line = null;
    		String user = username.getText();
    		String Password = password.getText();
    		write.println("MUSICIN "+user+" "+Password);
    		write.flush();
    		try {
    		 line = read.readLine();
    		}
    		catch(IOException d) {
    			
    			responses.setText("NO empty string");
    		}
    			
    			ResultofLogin.setText(line);
    		
    		
    	});
    	getList.setOnAction(e->{
    		
    		write.println("MUSICLIST");
    		write.flush();
    		try {
    			String line = read.readLine(); 
    			String [] lines = line.split("#");
    			for(String s : lines) {
    				
    				list.appendText(s+"\n");
    			}
    			
    			
    
    		
    		
    		
    		}
    		catch(IOException f) {
    			
    			list.setText("Invalid list  client logged out");
    		}
    		
    	});
    	
    	download.setOnAction(e->{
    		String ID=field.getText();
    	   
    		if(ID.isEmpty()){
    			
    			responses.setText("Invalid number entered ");
    		} 
    		else {
    		int iD = Integer.parseInt(ID);
    		int size=0;
    		String filename=null;
    		write.println("MUSICDOWN "+iD);
    		try {
				String Line = read.readLine();
				String[] lines = Line.split(" ");
				
				String response = lines[0];
				 size = Integer.parseInt(lines[1]);
				 
				 
				 
				 
				
				
				
				File filetoshow = new File("data/client/response.pdf");
				FileOutputStream fis = new FileOutputStream(filetoshow);
				DataInputStream dis = new DataInputStream(client.getInputStream());
				int totalbytes =0;
				int n =0;
				byte[]buffer = new byte[1024];
				while(totalbytes!=size) {
					
					n=dis.read(buffer,0,buffer.length);
					fis.write(buffer,0,n);
					fis.flush();
					totalbytes+=n;
					
				}
				result.setText("File saved to client");
				
			} catch (IOException e1) {
				
				responses.setText("Invalid file or request");
			}
    		}
    		
    		
    	});
    	logout.setOnAction(e->{
    		
    		write.println("MUSICOUT");
    		write.flush();
    		try {
				String respo = read.readLine();
				
				responses.appendText(respo);
			} catch (IOException e1) {
				
				responses.appendText("No line read");
			}
                 if(client!=null) {
    			
    			try {
					client.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					responses.setText("Failed to logoff client");
				}
    		}
    		
    		
    	});
    	
    }
    
    public void SetUP() {
    	this.setVgap(10);
    	this.setHgap(5);
    	connect = new Button("Connect");
    	this.add(connect,0, 0);
    	Connection = new TextField();
    	this.add(Connection, 0, 1);
    	username = new PasswordField();
    	this.add(username,0,2);
    	username.setPromptText("Enter your Username");
    	password = new PasswordField();
    	this.add(password, 1, 2);
    	password.setPromptText("Enter Your password");
    	Login = new Button("Login");
    	ResultofLogin=new TextField();
    	this.add(Login, 0, 3);
    	loginStatus = new Text("Login Status :");
    	this.add(loginStatus, 0, 4);
    	this.add(ResultofLogin, 0, 5);
    	text = new Text("Server Responses and Error messages : ");
    	this.add(text, 0, 6);
    	responses = new TextArea();
    	this.add(responses, 0, 7);
    	getList = new Button("GetList");
    	this.add(getList, 0,8);
    	list = new TextArea();
    	this.add(list,0, 9);
    	field = new TextField();
    	field.setPromptText("Enter ID of the pdf you wish to recieve" );
    	this.add(field, 0, 10);
    	download = new Button("Download");
    	this.add(download, 1, 10);
    	result = new TextField();
    	this.add(result, 0,11);
    	logout = new Button("Logout");
    	this.add(logout, 0, 12);
    }
    public void connection() {
    	try{
    	client = new Socket("localhost",2024);
		Connection.setText("Client Connected");
		write = new PrintWriter(client.getOutputStream(),true);
		read = new BufferedReader(new InputStreamReader(client.getInputStream()));
    	}
    	catch (UnknownHostException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			Connection.setText("No server running");
		}
    }
    
	
	
}