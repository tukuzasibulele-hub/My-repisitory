package csc2b.client;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Client extends Application {
	
	public static void main(String[] args) 
	{
		launch(args);
	}
	
	@Override
	public void start(Stage stage) throws Exception {
	
		MusicClientPane pane = new MusicClientPane(stage);
		Scene scene = new Scene(pane,800,800);
		stage.setScene(scene);
		stage.show();
		
	}

}
