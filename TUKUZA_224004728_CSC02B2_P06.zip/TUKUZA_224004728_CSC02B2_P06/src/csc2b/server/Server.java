package csc2b.server;
import csc2b.client.MusicClientPane;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args)
	{
		try {
			ServerSocket server = new ServerSocket(2024);
			System.out.println("Server Running");
			
			
			while(true) {
				
				Socket client = server.accept();
				Runnable run = new MusicHandler(client);
				Thread thread = new Thread(run);
				thread.start();
				
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
}
