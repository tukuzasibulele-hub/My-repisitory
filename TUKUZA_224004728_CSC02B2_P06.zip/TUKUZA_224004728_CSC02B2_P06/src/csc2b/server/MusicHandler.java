package csc2b.server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MusicHandler implements Runnable {
	
	private Socket connection;
	private PrintWriter write;
	private BufferedReader read;
	private FileInputStream fis;
	private DataOutputStream dos;
	private FileOutputStream fos;
	private DataInputStream dis;
	private boolean result;
	public MusicHandler(Socket connection) {
		this.connection = connection;
	}

	@Override
	public void run() {
		String request = null;
		try {
			write = new PrintWriter(connection.getOutputStream(),true);
			read = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		}
		catch(IOException e) {
			
			e.printStackTrace();
		}
		
		try {
			while((request = read.readLine())!=null) {
				System.out.println("Request received : " + request);
				StringTokenizer tokens = new StringTokenizer(request," ");
				String Command = tokens.nextToken();
				
				switch(Command) {
				case "MUSICIN" : 
					
					String Name = tokens.nextToken();
					String password = tokens.nextToken();
					 result = matchLogin(Name,password);
					if(result == true) {
					
					write.println(" YES User logged in can continue to other requests");
					write.flush();
					}
					
					else {
						
						write.println("No invalid details No more requests");
						read.close();
					}
					break;
					
				case"MUSICLIST":
					if(result == true) {
					StringBuilder build = new StringBuilder();
					System.out.println(getFileList());
					for(String s : getFileList()) {
						build.append(s).append("#");
					}
		
		
					write.println(build.toString());
					write.flush();
					}
					break;
					
				case"MUSICOUT":
					
					write.println("YES CLIENT LOGED OFF");
					write.flush();
					break;
					
				
					
					
					
				case "MUSICDOWN":
					
					String ID = tokens.nextToken();
					System.out.println("The ID requested :"+ID);
					String filename = null;
					String line;
					
					File file = new File("data/server/Docs.txt");
					Scanner scan = new Scanner(file);
					
					while(scan.hasNext()) {
						
						line = scan.nextLine();
						StringTokenizer Pokens = new StringTokenizer(line," ");
						String id = Pokens.nextToken();
						String Filename = Pokens.nextToken();
						
						if(id.equals(ID)) {
							
							filename = Filename;
							break;
						}
					}
					System.out.println("File name is :"+filename);
					
					File tosend = new File("data/server/"+filename);
					
					write.println("YES "+tosend.length());
					write.flush();
					
					fis = new FileInputStream(tosend);
					dos = new DataOutputStream(connection.getOutputStream());
					int n=0;
					byte [] buffer = new byte[1024];
					
					
					while((n=fis.read(buffer,0,buffer.length))>0) {
						
						dos.write(buffer,0,n);
						dos.flush();
					}
					fis.close();
					System.out.println("File sent to user");
					
					break;
					
					default:
						write.println("NO no command matches");
					
				}
				
				
				
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	

	
	private boolean matchLogin(String userN, String passW)
	{
		boolean found = false;

		File userFile = new File("data/server/Users.txt");
		try
		{
		    Scanner scan = new Scanner(userFile);
		    while(scan.hasNextLine())
		    {
			String line = scan.nextLine();
			StringTokenizer tokens = new StringTokenizer(line," ");
			String Username = tokens.nextToken();
			String password = tokens.nextToken();
			
			if(Username.equals(userN)&&password.equals(passW)) {
				found = true;
				
				break;
			}
			
			
		    }
		    scan.close();
		}
		catch(IOException ex)
		{
		    ex.printStackTrace();
		}
		
		return found;
	}
	
	private ArrayList<String> getFileList()
	{
		ArrayList<String> result = new ArrayList<String>();
		
		File file = new File("data/server/Docs.txt");
		String line = null;
		String newline = null;
		if(file.exists()) {
		try
		{ 
			Scanner scan = new Scanner(file);
			
			
			while(scan.hasNext()) {
				line = scan.nextLine();
				result.add(line);
				
			}
			

			scan.close();
			
		}	    
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		
		
	}
return result;}

	
	private String idToFileName(String strID)
	{
		String result ="";
		
		//Code to find the file name that matches strID
		File lstFile = new File(""/*OMITTED - Enter file location*/);
    	try
    	{
    		Scanner scan = new Scanner(lstFile);

    		String line = "";
    		//***OMITTED - Read filename from file and search for filename based on ID***
    		
    		
    		scan.close();
    	}
    	catch(IOException ex)
    	{
    		ex.printStackTrace();
    	}
		return result;
	}
}
